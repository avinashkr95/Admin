package com.eLearning.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningManagementApplication.class, args);
	}

}
