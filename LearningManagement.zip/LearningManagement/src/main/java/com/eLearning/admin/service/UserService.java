package com.eLearning.admin.service;

import java.util.List;

import com.eLearning.admin.model.User;

public interface UserService {

	User saveUser(User user);

	User updateUser(User user);

	void deleteUser(Long userId);

	User findByEmail(String email);

	List<User> findAllUser();

	Long numberOfUser();

}
