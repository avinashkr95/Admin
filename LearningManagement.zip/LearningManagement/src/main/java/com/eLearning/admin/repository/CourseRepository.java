package com.eLearning.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eLearning.admin.model.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {

}
