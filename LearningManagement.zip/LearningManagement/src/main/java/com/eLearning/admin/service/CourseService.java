package com.eLearning.admin.service;

import java.util.List;

import com.eLearning.admin.model.Course;

public interface CourseService {

	Course saveCourse(Course course);

	Course updateCourse(Course course);

	void deleteCourse(Long courseId);

	Long numberOfCourse();

	List<Course> findAllCourse();

}
