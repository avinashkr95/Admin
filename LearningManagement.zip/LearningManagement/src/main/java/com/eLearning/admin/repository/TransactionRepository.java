package com.eLearning.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eLearning.admin.model.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
}
