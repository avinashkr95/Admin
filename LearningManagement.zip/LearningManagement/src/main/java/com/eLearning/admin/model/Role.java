package com.eLearning.admin.model;

public enum Role {
	USER,
	ADMIN

}
