package com.eLearning.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eLearning.admin.model.Course;
import com.eLearning.admin.repository.CourseRepository;

@Service
@Transactional
public class CourseServiceImpl implements CourseService{
	
	@Autowired
	private CourseRepository courseRepository;
	
	@Override
	public Course saveCourse(Course course) {
		
		return courseRepository.save(course);
	}
	
	@Override
	public Course updateCourse(Course course) {
		
		return courseRepository.save(course);
	}
	
	@Override
	public void deleteCourse(Long courseId) {
		
		courseRepository.deleteById(courseId);
		
	}
	
	@Override
	public Long numberOfCourse() {
		
		return courseRepository.count();
	}
	
	@Override
	public List<Course> findAllCourse(){
		
		return courseRepository.findAll();
	}

}
