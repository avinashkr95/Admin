export class Course {
  id: number;
  name: string = "";
  price: number = 0;
  explanation: string = "";
}
