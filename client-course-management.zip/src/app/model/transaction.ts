import {Course} from './course';
import {User} from './user';
export class Transaction {
  id:number;
  course: Course;
  user: User;
  purchaseDate: any;
}
