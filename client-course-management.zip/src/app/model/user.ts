import {Role} from './role';
export class User {
  id: number;
  name: string="";
  phone: number=0;
  email: string="";
  role: Role;
  password: string="";
  confirmPassword: string ="";
  token: string="";
}
